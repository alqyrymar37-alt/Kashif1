# كاشف الأرقام الجديد – المشروع الكامل (خادم + أندرويد)

## 1) الخادم (Supabase)
1. أنشئ مشروعاً في supabase.com.
2. Authentication → Providers → فعّل **Anonymous sign-ins**.
3. SQL Editor: شغّل `backend/schema.sql` ثم `backend/directory.sql`، ثم نفّذ سطر pepper المعلّق مرة واحدة واحفظ قيمته في مكان آمن.
4. انسخ Project URL و anon key.

### دليل الأنشطة وتوثيقها
- التوثيق برمز SMS: انشر `backend/functions/send-business-code` وأضف أسرار TWILIO_SID وTWILIO_TOKEN وTWILIO_FROM.
- تحقق أن مزوّد SMS يدعم اليمن وبتكلفة مقبولة. البديل: توثيق يدوي بعد التواصل مع صاحب النشاط عبر واتساب: `select admin_verify_business('<id>');`
- بعد التوثيق يظهر اسم النشاط تلقائياً على شاشة المتصل أثناء المكالمة.

## 2) أندرويد
1. افتح مجلد `android` في Android Studio (أنشئ مشروعاً فارغاً بـ Compose وانسخ الملفات إليه إن لزم، مع ملفات Gradle الجذرية والـ plugins: com.android.application و org.jetbrains.kotlin.android و org.jetbrains.kotlin.plugin.compose).
2. في `gradle.properties` أضف:
   SUPABASE_URL=https://xxxx.supabase.co
   SUPABASE_ANON_KEY=eyJ...
3. شغّل التطبيق، اضغط «تفعيل كشف المكالمات الواردة» وامنح الدور.

## ملاحظات مهمة
- الكود لم يُجرَّب على جهاز أو مُحاكٍ (لا يتوفر Android SDK هنا)؛ توقّع تعديلات بسيطة عند أول تشغيل.
- مكافحة التلاعب: الدخول المجهول يسمح بإنشاء حسابات كثيرة؛ قبل الإطلاق أضف Play Integrity أو تحقق برقم الهاتف، وهذا ما يجعل شرط «5 مستخدمين» ذا قيمة.
- التحقق من ملكية النشاط التجاري: Edge Function ترسل رمز SMS للرقم ثم تضع verified=true.
- أضف: سياسة خصوصية منشورة برابط، وحذف تلقائي للبيانات القديمة، واستشر محامياً محلياً (PDPL السعودي، قانون 151 المصري، GDPR...).
- راجع سياسات Google Play الخاصة بتطبيقات الاتصال وفحص المكالمات قبل النشر.
